import tkinter as tk
from tkinter import ttk, messagebox
import psycopg2

def ket_noi_csdl():
    try:
        ket_noi = psycopg2.connect(
            dbname="BaiThi",
            user="postgres",
            password="12344321",
            host="localhost",
            port="5432"
        )
        return ket_noi
    except Exception as e:
        print(f"Không thể kết nối cơ sở dữ liệu: {e}")
        return None

def login():
    username = nhap_ten_dn.get()
    password = nhap_mat_khau.get()

    ket_noi = ket_noi_csdl()
    if not ket_noi:
        return
    con_tro = ket_noi.cursor()
    con_tro.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
    user = con_tro.fetchone()
    ket_noi.close()

    if user:
        messagebox.showinfo("Thông báo", "Đăng nhập thành công!")
        cua_so_dang_nhap.destroy()
        mo_cua_so_chinh()
    else:
        messagebox.showerror("Lỗi", "Tên đăng nhập hoặc mật khẩu không đúng!")

def register():
    username = nhap_ten_dn.get()
    password = nhap_mat_khau.get()

    ket_noi = ket_noi_csdl()
    if not ket_noi:
        return
    con_tro = ket_noi.cursor()
    con_tro.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
    ket_noi.commit()
    ket_noi.close()

    messagebox.showinfo("Thông báo", "Đăng ký thành công!")
    mo_cua_so_dang_nhap()

def mo_cua_so_chinh():
    global cua_so
    cua_so = tk.Tk()
    cua_so.title("Quản lý Sinh Viên")

    tk.Label(cua_so, text="Tên:").grid(row=0, column=0)
    nhap_ten = tk.Entry(cua_so)
    nhap_ten.grid(row=0, column=1)

    tk.Label(cua_so, text="Tuổi:").grid(row=0, column=2)
    nhap_tuoi = tk.Entry(cua_so)
    nhap_tuoi.grid(row=0, column=3)

    tk.Label(cua_so, text="Giới tính:").grid(row=1, column=0)
    nhap_gioi_tinh = tk.Entry(cua_so)
    nhap_gioi_tinh.grid(row=1, column=1)

    tk.Label(cua_so, text="Ngành học:").grid(row=1, column=2)
    nhap_nganh_hoc = tk.Entry(cua_so)
    nhap_nganh_hoc.grid(row=1, column=3)

    cot = ('ID', 'Tên', 'Tuổi', 'Giới tính', 'Ngành')
    bang = ttk.Treeview(cua_so, columns=cot, show='headings')

    for cot_ten in cot:
        bang.heading(cot_ten, text=cot_ten)

    bang.grid(row=2, column=0, columnspan=4)

    nut_them = tk.Button(cua_so, text="Thêm sinh viên", command=lambda: them_sinh_vien(nhap_ten, nhap_tuoi, nhap_gioi_tinh, nhap_nganh_hoc, bang))
    nut_them.grid(row=3, column=0)

    def tai_lai_danh_sach():
        for item in bang.get_children():
            bang.delete(item)

        ket_noi = ket_noi_csdl()
        con_tro = ket_noi.cursor()

        con_tro.execute("SELECT * FROM students")
        hang = con_tro.fetchall()

        for du_lieu in hang:
            bang.insert('', tk.END, values=du_lieu)

        ket_noi.close()

    nut_tai_lai = tk.Button(cua_so, text="Tải lại danh sách", command=tai_lai_danh_sach)
    nut_tai_lai.grid(row=3, column=3)

    cua_so.mainloop()

def them_sinh_vien(nhap_ten, nhap_tuoi, nhap_gioi_tinh, nhap_nganh_hoc, bang):
    try:
        ket_noi = ket_noi_csdl()
        con_tro = ket_noi.cursor()

        ten = nhap_ten.get()
        tuoi = int(nhap_tuoi.get())
        gioi_tinh = nhap_gioi_tinh.get()
        nganh = nhap_nganh_hoc.get()

        # Thêm sinh viên và lấy ID tự động
        cau_lenh = """
        INSERT INTO students (name, age, gender, major) 
        VALUES (%s, %s, %s, %s) RETURNING id
        """
        con_tro.execute(cau_lenh, (ten, tuoi, gioi_tinh, nganh))
        student_id = con_tro.fetchone()[0]  # Lấy ID mới thêm
        ket_noi.commit()
        ket_noi.close()

        # Thêm sinh viên vào bảng giao diện
        bang.insert('', tk.END, values=(student_id, ten, tuoi, gioi_tinh, nganh))
    except Exception as e:
        messagebox.showerror("Lỗi", f"Không thể thêm sinh viên: {e}")


def mo_cua_so_dang_nhap():
    global cua_so_dang_nhap, nhap_ten_dn, nhap_mat_khau
    cua_so_dang_nhap = tk.Tk()
    cua_so_dang_nhap.title("Đăng nhập/Đăng ký")

    tk.Label(cua_so_dang_nhap, text="Tên đăng nhập:").grid(row=0, column=0)
    nhap_ten_dn = tk.Entry(cua_so_dang_nhap)
    nhap_ten_dn.grid(row=0, column=1)

    tk.Label(cua_so_dang_nhap, text="Mật khẩu:").grid(row=1, column=0)
    nhap_mat_khau = tk.Entry(cua_so_dang_nhap, show="*")
    nhap_mat_khau.grid(row=1, column=1)

    nut_dang_nhap = tk.Button(cua_so_dang_nhap, text="Đăng nhập", command=login)
    nut_dang_nhap.grid(row=2, column=0)

    nut_dang_ky = tk.Button(cua_so_dang_nhap, text="Đăng ký", command=register)
    nut_dang_ky.grid(row=2, column=1)

    cua_so_dang_nhap.mainloop()
    
def chinh_sua_sinh_vien(bang, nhap_ten, nhap_tuoi, nhap_gioi_tinh, nhap_nganh_hoc):
    try:
        selected_item = bang.selection()[0]  # Lấy mục đang chọn
        values = bang.item(selected_item, "values")
        student_id = values[0]

        ten = nhap_ten.get()
        tuoi = int(nhap_tuoi.get())
        gioi_tinh = nhap_gioi_tinh.get()
        nganh = nhap_nganh_hoc.get()

        ket_noi = ket_noi_csdl()
        con_tro = ket_noi.cursor()
        cau_lenh = """
        UPDATE students 
        SET name = %s, age = %s, gender = %s, major = %s
        WHERE id = %s
        """
        con_tro.execute(cau_lenh, (ten, tuoi, gioi_tinh, nganh, student_id))
        ket_noi.commit()
        ket_noi.close()

        messagebox.showinfo("Thông báo", "Chỉnh sửa thành công!")
        bang.item(selected_item, values=(student_id, ten, tuoi, gioi_tinh, nganh))
    except Exception as e:
        messagebox.showerror("Lỗi", f"Không thể chỉnh sửa sinh viên: {e}")


def xoa_sinh_vien(bang):
    try:
        selected_item = bang.selection()[0]  # Lấy mục đang chọn
        values = bang.item(selected_item, "values")
        student_id = values[0]

        ket_noi = ket_noi_csdl()
        con_tro = ket_noi.cursor()
        cau_lenh = "DELETE FROM students WHERE id = %s"
        con_tro.execute(cau_lenh, (student_id,))
        ket_noi.commit()
        ket_noi.close()

        bang.delete(selected_item)
        messagebox.showinfo("Thông báo", "Xóa thành công!")
    except Exception as e:
        messagebox.showerror("Lỗi", f"Không thể xóa sinh viên: {e}")

def mo_cua_so_chinh():
    global cua_so
    cua_so = tk.Tk()
    cua_so.title("Quản lý Sinh Viên")

    tk.Label(cua_so, text="Tên:").grid(row=0, column=0)
    nhap_ten = tk.Entry(cua_so)
    nhap_ten.grid(row=0, column=1)

    tk.Label(cua_so, text="Tuổi:").grid(row=0, column=2)
    nhap_tuoi = tk.Entry(cua_so)
    nhap_tuoi.grid(row=0, column=3)

    tk.Label(cua_so, text="Giới tính:").grid(row=1, column=0)
    nhap_gioi_tinh = tk.Entry(cua_so)
    nhap_gioi_tinh.grid(row=1, column=1)

    tk.Label(cua_so, text="Ngành học:").grid(row=1, column=2)
    nhap_nganh_hoc = tk.Entry(cua_so)
    nhap_nganh_hoc.grid(row=1, column=3)

    cot = ('ID', 'Tên', 'Tuổi', 'Giới tính', 'Ngành')
    bang = ttk.Treeview(cua_so, columns=cot, show='headings')

    for cot_ten in cot:
        bang.heading(cot_ten, text=cot_ten)

    bang.grid(row=2, column=0, columnspan=4)

    nut_them = tk.Button(cua_so, text="Thêm sinh viên", command=lambda: them_sinh_vien(nhap_ten, nhap_tuoi, nhap_gioi_tinh, nhap_nganh_hoc, bang))
    nut_them.grid(row=3, column=0)

    nut_chinh_sua = tk.Button(cua_so, text="Chỉnh sửa", command=lambda: chinh_sua_sinh_vien(bang, nhap_ten, nhap_tuoi, nhap_gioi_tinh, nhap_nganh_hoc))
    nut_chinh_sua.grid(row=3, column=1)

    nut_xoa = tk.Button(cua_so, text="Xóa sinh viên", command=lambda: xoa_sinh_vien(bang))
    nut_xoa.grid(row=3, column=2)

    def tai_lai_danh_sach():
        for item in bang.get_children():
            bang.delete(item)

        ket_noi = ket_noi_csdl()
        con_tro = ket_noi.cursor()

        con_tro.execute("SELECT * FROM students")
        hang = con_tro.fetchall()

        for du_lieu in hang:
            bang.insert('', tk.END, values=du_lieu)

        ket_noi.close()

    nut_tai_lai = tk.Button(cua_so, text="Tải lại danh sách", command=tai_lai_danh_sach)
    nut_tai_lai.grid(row=3, column=3)

    cua_so.mainloop()


mo_cua_so_dang_nhap()
